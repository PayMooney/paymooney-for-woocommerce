<?php
/*
 * Plugin Name: PayMooney Payment Gateway for WooCommerce
 * Plugin URI: https://paymooney.com
 * Description: Make payments on your store with PayMooney.
 * Author: Giresse Ayefou
 * Author URI: https://paymooney.com
 * Version: 1.0.1
 * Text Domain: paymooney
 *
 
 /*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
 
 
add_filter( 'woocommerce_payment_gateways', 'paymooney_add_gateway_class' );
function paymooney_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Paymooney_Gateway'; // your class name is here
	return $gateways;
}
 
/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'paymooney_init_gateway_class' );
function paymooney_init_gateway_class() {
 
	class WC_Paymooney_Gateway extends WC_Payment_Gateway {
 
		private $allowedCurrencies = array(
					 'XAF' ,'EUR' ,'USD'
		  );
		private $SUCCESS_CALLBACK_URL = "wc_payment_success";
		private $FAILURE_CALLBACK_URL = "wc_payment_failure";
		private $SUCCESS_REDIRECT_URL = "/checkout/order-received/";
		private $FAILURE_REDIRECT_URL = "/checkout/order-received/";
		private $API_HOST = "https://paymooney.com";
		private $API_SESSION_CREATE_ENDPOINT = "/api/v1.0/payment_url";
 		/**
 		 * Class constructor, more about it in Step 3
 		 */
 		public function __construct() {
 
			$this->id = 'wc-paymooney'; // payment gateway plugin ID
			$this->icon = 'https://paymooney.com/images/wc-api.png'; // URL of the icon that will be displayed on checkout page near your gateway name
			$this->has_fields = true; // in case you need a custom credit card form
			$this->method_title = 'PayMooney';
			$this->method_description = 'Accept payments on your store with PayMooney'; // will be displayed on the options page
		 
			// gateways can support subscriptions, refunds, saved payment methods,
			// but in this tutorial we begin with simple payments
			$this->supports = array(
				'products'
			);
		 
			// Method with all the options fields
			$this->init_form_fields();
		 
			// Load the settings.
			$this->init_settings();
			$this->title = $this->get_option( 'title' );
			$this->description = $this->get_option( 'description' );
			 // Checking if valid to use
			if($this->is_valid_for_use()) {
			 $this->enabled = $this->get_option( 'enabled' );
			}
			else {
				$this->enabled = 'no';
			}

			// Site URL
			$this->siteUrl = get_site_url();
			$this->testmode = 'yes' === $this->get_option( 'testmode' );
			$this->private_key = $this->get_option( 'private_key' );
			$this->publishable_key = $this->get_option( 'publishable_key' );
		 
			// This action hook saves the settings
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			
			// You can also register a webhook here
			add_action( 'woocommerce_api_'. $this->SUCCESS_CALLBACK_URL, array( $this, 'payment_success'));
			add_action( 'woocommerce_api_' . $this->FAILURE_CALLBACK_URL, array( $this, 'payment_failure'));
		 
	
 
 		}
 
		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
 		public function init_form_fields(){
 
				$this->form_fields = array(
				'enabled' => array(
					'title'       => 'Enable/Disable',
					'label'       => 'Enable PayMooney',
					'type'        => 'checkbox',
					'description' => '',
					'default'     => 'no'
				),
				'title' => array(
					'title'       => 'Title',
					'type'        => 'text',
					'description' => 'This controls the title which the user sees during checkout.',
					'default'     => 'PayMooney',
					'desc_tip'    => true,
				),
				'description' => array(
					'title'       => 'Description',
					'type'        => 'textarea',
					'description' => 'This controls the description which the user sees during checkout.',
					'default'     => 'Pay now via our super-cool payment gateway.',
				),
				'testmode' => array(
					'title'       => 'Test mode',
					'label'       => 'Enable Test Mode',
					'type'        => 'checkbox',
					'description' => 'Place the payment gateway in test mode using test API keys.',
					'default'     => 'yes',
					'desc_tip'    => true,
				),
				'publishable_key' => array(
					'title'       => 'Live Publishable Key',
					'type'        => 'text'
				),
				'private_key' => array(
					'title'       => 'Live Private Key',
					'type'        => 'password'
				)
			);
		 
	 	}
		
		function is_valid_for_use () {
        return in_array(get_woocommerce_currency(), $this->allowedCurrencies);
		}

		function admin_options() {
				if ( $this->is_valid_for_use() ) {
			parent::admin_options();
		} 
		else {
					?>
						<div class="notice error is-dismissible" >
						 <p><?php _e( 'App Does not support the selected currency ' . get_woocommerce_currency() . '!', 'my-text-domain' ); ?></p>
						</div>
					<?php
			  }
		}
 
		/**
		 * You will need it if you want your custom credit card form, Step 4 is about it
		 */
		public function payment_fields() {
 
		
 
		}
 
		/*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
	 	public function payment_scripts() {
 
		
 
	 	}
 
		/*
 		 * Fields validation, more in Step 5
		 */
		public function validate_fields() {
		
		if( empty( $_POST[ 'billing_first_name' ]) ) {
			wc_add_notice(  'First name is required!', 'error' );
			return false;
		}
		return true;
		
 
		}
 
		/*
		 * We're processing the payments here, everything about it is in Step 5
		 */
		public function process_payment( $order_id ) {
 
		global $woocommerce;
  
//To receive order id 
        $order = wc_get_order( $order_id );
		
		$items = $order->get_items();
		$title="";
		$des="";
		foreach ( $items as $item ) {
		  
			$product = wc_get_product( $item['product_id'] );

			$title=$title.$product->get_name();
			$des=$des.$product->get_description();
		  
		}

//To receive order amount
        $amount = $order->get_total();

//To receive woocommerce Currency
        $currency = get_woocommerce_currency();

//To receive user id and order details
        $merchantCustomerId = $order->get_user_id();
        $merchantOrderId = $order->get_order_number();
        $orderIdString = '?orderId=' . $order_id;
        $transaction = array(
            "amount" => $amount,
            "currency" => $currency,
        );
        $transactions = array(
            $transaction
        );
//Create a session and send it to Payment platform while handling errors 
		$mode="live";
		if($this->testmode) $mode="test";
       $requestBody = array(
			'amount' => $amount,
            'currency_code' => $currency,
            'public_key' => $this->publishable_key,
            'item_ref' => $merchantOrderId,
			'item_name' => $title,
			'description' => $des,
			'email' => $order->get_billing_email(),
			'phone' => $order->get_billing_phone(),
			'first_name' => $order->get_billing_first_name(),
			'last_name' => $order->get_billing_last_name(),
			'lang' => 'en',
			'logo' => 'https://paymooney.com/images/logo_paymooney2.png',
            "redirectUrl" => $this->siteUrl . $this->SUCCESS_REDIRECT_URL . $orderIdString,
            "redirectOnFailureUrl" => $this->siteUrl . $this->FAILURE_REDIRECT_URL . $orderIdString,
            "callbackUrl" => $this->siteUrl . "//wc-api/" . $this->SUCCESS_CALLBACK_URL . $orderIdString,
            "callbackOnFailureUrl" => $this->siteUrl . "//wc-api/" . $this->FAILURE_CALLBACK_URL . $orderIdString,
            "redirectTarget" => "TOP",
            "merchantCustomerId" => $merchantCustomerId,
			'environement' => $mode
        );

		

        $header = array(
            'Authorization' => $this->private_key,
            'Content-Type' => 'application/json'
        );
		
        $args = array(
            'method' => 'POST',
			'timeout'     => 45,
            'body' => $requestBody
        );
        
        $apiUrl = $this->API_HOST . $this->API_SESSION_CREATE_ENDPOINT;
		
        $response = wp_remote_post( $apiUrl, $args );   
		$response = wp_remote_retrieve_body($response);
        if( !is_wp_error( $response ) ) {
            $body = json_decode( $response, true );
			
		
            if ( $body['response'] == 'success' ) {
                //$sessionId = $body['payload']['sessionId'];
                $url = $body['payment_url'];
				$link_array = explode('/',$url);
			    $sessionId = end($link_array);
                $order->update_meta_data( 'myApp_session_id', $sessionId );
                $session_note = "MyApp SessionID: " . $sessionId;
                $order->add_order_note( $session_note );
                update_post_meta( $order_id, '_session_id', $sessionId );
                $order->update_status( 'processing');
                return array(
                    'result' => 'success',
                    'redirect' => $url
                );
		    } else {
                wc_add_notice(  'Please try again', 'error' );
                return;
		    }
        } else {
            wc_add_notice(  'Connection error.', 'error' );
            return;
        }
 
	 	}
 
		/*
		 * In case you need a webhook, like PayPal IPN etc
		 */
		public function payment_success() {
        // Getting POST data
        //$postData = file_get_contents( 'php://input' );
        //$response  = json_decode( $postData );
        $orderId = $_GET['orderId'];
        $order = wc_get_order( $orderId );
		$status="";
		if(isset($_POST["status"]))
			$status=$_POST["status"];
        
        if ($order) {
            //$order->update_meta_data( 'myApp_callback_payload', $postData );
             if ( $status == 'Success' ) {
                $order->update_meta_data( 'myApp_event', 'CHECKOUT_SUCCEEDED' );
                /*if ($response->payload->reservations && $response->payload->reservations[0] && $response->payload->reservations[0]->reservationId) {
                    $order->update_meta_data( 'myApp_reservation_id', $response->payload->reservations[0]->reservationId );
                    $reservation_note = "MyApp ReservationID: " . $response->payload->reservations[0]->reservationId;
                    $order->add_order_note( $reservation_note );
                    update_post_meta( $orderId, '_myApp_reservation_id', $response->payload->reservations[0]->reservationId );
                }*/
                $order->update_status( 'completed');
                $order->payment_complete();
                $order->reduce_order_stock();
            } else if ( $status == 'Failed' ) {
                $order->update_meta_data( 'myApp_event', 'failed' );
                /*if ($response->payload->reservations && $response->payload->reservations[0] && $response->payload->reservations[0]->reservationId) {
                    $order->update_meta_data( 'myApp_reservation_id', $response->payload->reservations[0]->reservationId );
                }*/
                $order->update_status( 'failed');
            }
        }
    }
	
	public function payment_failure() {
        // Getting POST data
        //$postData = file_get_contents( 'php://input' );
        //$response  = json_decode( $postData );
        $orderId = $_GET['orderId'];
        $order = wc_get_order( $orderId );

        if ($order) {
            //$order->update_meta_data( 'myApp_callback_payload', $postData );
            $order->update_meta_data( 'myApp_event', 'Failed' );
            /*if ($response->payload->reservations && $response->payload->reservations[0] && $response->payload->reservations[0]->reservationId) {
                $order->update_meta_data( 'myApp_reservation_id', $response->payload->reservations[0]->reservationId );
            }*/
            $order->update_status( 'failed');
        }
    }


		
		
		
 	}
}